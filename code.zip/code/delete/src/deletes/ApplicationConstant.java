package deletes;


public class ApplicationConstant{	
	public static final String APP_CONFIGURATION ="mailconfig.properties";
	public static final String APP_Subject = "config_APPLSUBJECT";
	public static final String APP_BODY = "config_APPLBODY";
	public static final String APP_BODY2 = "config_APPLBODY2";
	
	public static final String MAILINGID = "config_MAILINGID";
	public static final String MHOST = "config_MHOST";
	public static final String Excelpath = "config_Excelpath";

}
