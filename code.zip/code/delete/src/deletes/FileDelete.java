package deletes;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import com.sun.mail.util.MailConnectException;

class FileDelete
{

public static void main(String ar[]) throws FileNotFoundException, MailConnectException, IOException
{   
	FileDelete obj=new FileDelete();
	int noofurls = 0;
	int countnotdeleted=0;
	Date date = new Date();
	SimpleDateFormat sdf1 = new SimpleDateFormat("MM-dd-yyyy");
	String curDir = System.getProperty("user.dir");
	File f1 = new File(curDir + "/"+ ApplicationConstant.APP_CONFIGURATION);
	FileInputStream in = new FileInputStream(f1);
	List<String> urllist=new ArrayList<String>(); 
    List<String> deletedfilelist=new ArrayList<String>(); 
	 List<String> amiMailRecipients=new ArrayList<String>();
	 confgProperties.load(in);
	 Label label1;
	  try {
		 String fileName = "DeletedOldLogs_"+sdf1.format(date);
		 WritableWorkbook workbook = Workbook.createWorkbook(new File(confgProperties.getProperty(ApplicationConstant.Excelpath)+fileName+".xls"));
			
		    
		   
//		    	 label1 = new Label (0,1,String.valueOf("Hello")); // \n is for to write in a new Line .  
//		    	 sheet.addCell(label1);
		    //	System.out.println(deletedfiles.get(i));
		    		
		    	
		 
    
	try {
		File file1 = new File("mail.properties");
  		FileInputStream fileInput1 = new FileInputStream(file1);
  		Properties properties1 = new Properties();
  		properties1.load(fileInput1);
  		fileInput1.close();

  		Enumeration<Object> enuKeys1 = properties1.keys();
  		while (enuKeys1.hasMoreElements()) {
  			String key1 = (String) enuKeys1.nextElement();
  			String value1 = properties1.getProperty(key1);
   			//System.out.println(value);
  			amiMailRecipients.add(value1);
  		}
  		
  		
  		File file = new File("url.properties");
  		FileInputStream fileInput = new FileInputStream(file);
  		Properties properties = new Properties();
  		properties.load(fileInput);
  		fileInput.close();
  		Enumeration<Object> enuKeys = properties.keys();
  		while (enuKeys.hasMoreElements()) {
  			String key = (String) enuKeys.nextElement();
  			String value = properties.getProperty(key);
   			//System.out.println(value);
  			urllist.add(value);
  		}
  		
  	} catch (FileNotFoundException e) {
  		e.printStackTrace();
  	} catch (IOException e) {
  		e.printStackTrace();
  	}
	for(String temp:urllist) {
		 int count=0;
		File f=new File(temp);
		String foldername=f.getName();
		WritableSheet sheet=  workbook.createSheet(foldername, 0);
		String list[]=f.list();
		noofurls=urllist.size();
		Calendar lCal = Calendar.getInstance(); 
		lCal.add(Calendar.DATE, -180); 
		for(int i=0;i<list.length;i++)
		{
		//System.out.println(list[i]);    //getting all files which is present in specified path
		File tmpFile=new File(temp+"/"+list[i]); 
		Date olddate = lCal.getTime();  // getting old dates
		//System.out.println(tmpFile);
        
		Date lastmodifiedDate=new Date(tmpFile.lastModified());  // getting last modified date of the file which you want to delete
		//System.out.println(lastmodifiedDate);
		if(lastmodifiedDate.before(olddate)) //checking whether the file is before the current date.
		{
		tmpFile.delete(); //deleting the file.
		count++;
		deletedfilelist.add(list[i]);
		
		}
		else{
			//System.out.println("No log files deleted");
			
		}
		}
		if(count==0){
			deletedfilelist.add("No log files deleted today");
			countnotdeleted++;
		}
		 for(int i=0;i<deletedfilelist.size();i++){
	    	 label1 = new Label (0,i,String.valueOf(deletedfilelist.get(i))); // \n is for to write in a new Line .  
	    	 sheet.addCell(label1);
	    System.out.println(deletedfilelist.get(i));
	    		
	    	}
		 deletedfilelist.removeAll(deletedfilelist);
		
		}
	//System.out.println(noofurls);
	//System.out.println(countnotdeleted);
  
	   workbook.write();
	    workbook.close();
	} catch (WriteException e) {

	}
	  if(noofurls==countnotdeleted){
		   obj.sendEmail(amiMailRecipients,"notdeleted");
	   }else{
		obj.sendEmail(amiMailRecipients,"deleted");
	   }

}
static Properties confgProperties = new Properties();
public void sendEmail(List<String> amiMailRecipients,String body)throws IOException,FileNotFoundException,MailConnectException {
	String curDir = System.getProperty("user.dir");
	File f = new File(curDir + "/"+ ApplicationConstant.APP_CONFIGURATION);
	FileInputStream in = new FileInputStream(f);
	confgProperties.load(in);
	String mailHost = null;
	String subject = null;
	String bodyString = null;
	
	String from = confgProperties.getProperty(ApplicationConstant.MAILINGID);
	Date date = new Date();
	SimpleDateFormat sdf1 = new SimpleDateFormat("MM-dd-yyyy");
	 String fileName = "DeletedOldLogs_"+sdf1.format(date)+".xls";
    String attachment=confgProperties.getProperty(ApplicationConstant.Excelpath)+fileName;
	System.out.println(attachment);

		try {
			
			subject = "Error Report " +confgProperties.getProperty(ApplicationConstant.APP_Subject)+" "+ new Date();	
	if(body.equals("deleted")){
			bodyString = confgProperties.getProperty(ApplicationConstant.APP_BODY);
	}else{
		bodyString = confgProperties.getProperty(ApplicationConstant.APP_BODY2);
	}	
			InternetAddress[] recepList = new InternetAddress[amiMailRecipients.size()];
			for (int i = 0; i < amiMailRecipients.size(); i++) {
				
				recepList[i] = new InternetAddress(amiMailRecipients.get(i));
				//System.out.println(amiMailRecipients.get(i));
			}
			// Get system properties
			Properties props = System.getProperties();

			// Specify the desired SMTP server
			mailHost= confgProperties.getProperty(ApplicationConstant.MHOST);
			//System.out.println("mailHost"+mailHost);
			props.put("mail.smtp.host", mailHost);
			// create a new Session object
			Session session = Session.getInstance(props, null);

			// create a new MimeMessage object (using the Session created
			// above)
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.setRecipients(Message.RecipientType.TO, recepList);
			message.setSubject(subject);
			message.setSentDate(new Date());
			BodyPart messageBodyPart1 = new MimeBodyPart();  
		    messageBodyPart1.setText(bodyString);   	
	        MimeBodyPart messageBodyPart = new MimeBodyPart();
			Multipart multipart = new MimeMultipart();
	       
			//fw1 = confgProperties.getProperty(ApplicationConstant.EXCELPATH)+fileName; //CR114123
	        
	        if(body.equals("deleted")){
	        	DataSource source = new FileDataSource(attachment);
		        messageBodyPart.setText(bodyString);
	        messageBodyPart.setDataHandler(new DataHandler(source));
	       messageBodyPart.setFileName(fileName);
	       multipart.addBodyPart(messageBodyPart);
	        }else{
	        	
	        }
	        
	        multipart.addBodyPart(messageBodyPart1);
			message.setContent(multipart);
			Transport.send(message);
		} catch (Throwable t) {

			System.err.println("Unable to send the email to all receipients"+t);
			// t.printStackTrace();

		}	
	
}
//public void createExcel(List<String> deletedfiles) throws IOException{
//	Date date = new Date();
//	SimpleDateFormat sdf1 = new SimpleDateFormat("MM-dd-yyyy");
//	String curDir = System.getProperty("user.dir");
//	File f = new File(curDir + "/"+ ApplicationConstant.APP_CONFIGURATION);
//	FileInputStream in = new FileInputStream(f);
//	confgProperties.load(in);
//	 Label label1;
//	try {
//	    String fileName = "DeletedLogs_"+sdf1.format(date);
//	    WritableWorkbook workbook = Workbook.createWorkbook(new File(confgProperties.getProperty(ApplicationConstant.Excelpath)+fileName+".xls"));
//	    WritableSheet sheet=  workbook.createSheet("ListOfDeletedFiles", 0);
//	    for(int i=0;i<deletedfiles.size();i++){
//	    	 label1 = new Label (0,i,String.valueOf(deletedfiles.get(i))); // \n is for to write in a new Line .  
//	    	 sheet.addCell(label1);
//	    //	System.out.println(deletedfiles.get(i));
//	    		
//	    	}
//	    workbook.write();
//	    workbook.close();
//	} catch (WriteException e) {
//
//	}
//	
//}

}
